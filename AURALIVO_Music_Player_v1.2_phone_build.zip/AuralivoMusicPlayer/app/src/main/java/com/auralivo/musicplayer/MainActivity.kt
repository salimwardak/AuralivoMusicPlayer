package com.auralivo.musicplayer

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.READ_MEDIA_AUDIO)
            else add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
        setContent { AuralivoApp() }
    }
}

private enum class Tab { Home, Songs, Albums, Playlists }

@Composable
fun AuralivoApp() {
    val context = LocalContext.current
    var songs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(Tab.Home) }
    var selected by remember { mutableStateOf<Song?>(null) }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var favorites by remember { mutableStateOf(loadFavorites(context)) }
    var showPlayer by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        songs = MusicRepository(context.contentResolver).loadSongs()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            controller = future.get()
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(value: Boolean) { isPlaying = value }
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val uri = mediaItem?.localConfiguration?.uri ?: return
                    selected = songs.firstOrNull { it.uri == uri }
                }
            })
        }, ContextCompat.getMainExecutor(context))
    }

    LaunchedEffect(controller, isPlaying) {
        while (controller != null) {
            position = controller?.currentPosition ?: 0L
            duration = controller?.duration?.takeIf { it > 0 } ?: (selected?.duration ?: 0L)
            delay(500)
        }
    }

    DisposableEffect(Unit) {
        onDispose { controller?.release() }
    }

    val filtered = songs.filter {
        val q = query.trim()
        q.isBlank() || listOf(it.title, it.artist, it.album).any { s -> s.contains(q, true) }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF09090D),
            surface = Color(0xFF14141B),
            surfaceVariant = Color(0xFF20202A),
            primary = Color(0xFFB8A7FF),
            onPrimary = Color(0xFF181321)
        )
    ) {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().background(Color(0xFF09090D))) {
                when (tab) {
                    Tab.Home -> HomeScreen(songs, query, { query = it }, filtered, favorites, onPlay = {
                        playSong(controller, songs, it); selected = it; showPlayer = true
                    }, onFavorite = {
                        favorites = toggleFavorite(context, favorites, it.id)
                    })
                    Tab.Songs -> LibraryScreen("All Songs", filtered, favorites, { playSong(controller, songs, it); selected = it; showPlayer = true }, { favorites = toggleFavorite(context, favorites, it.id) })
                    Tab.Albums -> AlbumsScreen(songs) { album ->
                        val first = songs.firstOrNull { it.album == album }
                        if (first != null) { playSong(controller, songs, first); selected = first; showPlayer = true }
                    }
                    Tab.Playlists -> PlaylistScreen(songs, favorites) { playSong(controller, songs, it); selected = it; showPlayer = true }
                }

                if (selected != null) {
                    MiniPlayer(selected!!, isPlaying, position, duration, {
                        showPlayer = true
                    }, {
                        if (isPlaying) controller?.pause() else controller?.play()
                    })
                }

                NavigationBar(containerColor = Color(0xFF111116)) {
                    NavItem("⌂", "Home", tab == Tab.Home) { tab = Tab.Home }
                    NavItem("♫", "Songs", tab == Tab.Songs) { tab = Tab.Songs }
                    NavItem("▣", "Albums", tab == Tab.Albums) { tab = Tab.Albums }
                    NavItem("≡", "Playlists", tab == Tab.Playlists) { tab = Tab.Playlists }
                }
            }

            if (showPlayer && selected != null) {
                NowPlayingScreen(selected!!, isPlaying, position, duration,
                    onBack = { showPlayer = false },
                    onPlay = { if (isPlaying) controller?.pause() else controller?.play() },
                    onNext = { controller?.seekToNextMediaItem() },
                    onPrevious = { controller?.seekToPreviousMediaItem() },
                    onSeek = { controller?.seekTo(it) }
                )
            }
        }
    }
}

@Composable
private fun NavItem(icon: String, label: String, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(selected, onClick, icon = { Text(icon, fontSize = 20.sp) }, label = { Text(label, fontSize = 11.sp) })
}

@Composable
private fun HomeScreen(
    songs: List<Song>, query: String, onQuery: (String) -> Unit, filtered: List<Song>, favorites: Set<Long>, onPlay: (Song) -> Unit, onFavorite: (Song) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 22.dp)) {
            Text("AURALIVO", fontSize = 29.sp, fontWeight = FontWeight.Bold)
            Text("Your Music. Your Atmosphere.", color = Color.Gray, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(18.dp), placeholder = { Text("Search your music") })
            Spacer(Modifier.height(22.dp))
            Text("Your Library", fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Text("${songs.size} songs", color = Color.Gray, fontSize = 13.sp)
        }
        if (songs.isEmpty()) EmptyState()
        else LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 20.dp)) {
            items(filtered, key = { it.id }) { SongRow(it, favorites.contains(it.id), onPlay, onFavorite) }
        }
    }
}

@Composable
private fun LibraryScreen(title: String, songs: List<Song>, favorites: Set<Long>, onPlay: (Song) -> Unit, onFavorite: (Song) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Text(title, Modifier.padding(20.dp), fontSize = 25.sp, fontWeight = FontWeight.Bold)
        if (songs.isEmpty()) EmptyState()
        else LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 20.dp)) {
            items(songs, key = { it.id }) { SongRow(it, favorites.contains(it.id), onPlay, onFavorite) }
        }
    }
}

@Composable
private fun AlbumsScreen(songs: List<Song>, onAlbum: (String) -> Unit) {
    val albums = songs.groupBy { it.album }
    Column(Modifier.fillMaxSize()) {
        Text("Albums", Modifier.padding(20.dp), fontSize = 25.sp, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 20.dp)) {
            items(albums.keys.toList()) { album ->
                val first = albums[album]!!.first()
                Row(Modifier.fillMaxWidth().clickable { onAlbum(album) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Artwork(first, 58.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) { Text(album, fontWeight = FontWeight.Medium); Text("${albums[album]!!.size} songs", color = Color.Gray, fontSize = 13.sp) }
                    Text("▶", fontSize = 18.sp)
                }
            }
        }
    }
}

@Composable
private fun PlaylistScreen(songs: List<Song>, favorites: Set<Long>, onPlay: (Song) -> Unit) {
    val favSongs = songs.filter { favorites.contains(it.id) }
    Column(Modifier.fillMaxSize()) {
        Text("Playlists", Modifier.padding(20.dp), fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Favorites", Modifier.padding(horizontal = 20.dp), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text("${favSongs.size} songs", Modifier.padding(horizontal = 20.dp, vertical = 4.dp), color = Color.Gray, fontSize = 13.sp)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 20.dp)) {
            items(favSongs, key = { it.id }) { SongRow(it, true, onPlay, {}) }
        }
    }
}

@Composable
private fun SongRow(song: Song, favorite: Boolean, onPlay: (Song) -> Unit, onFavorite: (Song) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onPlay(song) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Artwork(song, 58.dp)
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(song.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${song.artist} • ${song.album}", color = Color.Gray, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(if (favorite) "♥" else "♡", color = if (favorite) Color(0xFFFF9AA8) else Color.Gray, fontSize = 24.sp, modifier = Modifier.clickable { onFavorite(song) }.padding(8.dp))
    }
}

@Composable
private fun Artwork(song: Song, size: androidx.compose.ui.unit.Dp) {
    AsyncImage(model = song.artwork, contentDescription = null, modifier = Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(Color(0xFF292631)), contentScale = ContentScale.Crop)
}

@Composable
private fun MiniPlayer(song: Song, playing: Boolean, position: Long, duration: Long, onOpen: () -> Unit, onPlay: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF18181F)).clickable { onOpen() }) {
        LinearProgressIndicator(progress = { if (duration > 0) position.toFloat() / duration else 0f }, Modifier.fillMaxWidth().height(2.dp))
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Artwork(song, 48.dp); Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(song.title, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(song.artist, color = Color.Gray, fontSize = 12.sp) }
            Text(if (playing) "Ⅱ" else "▶", fontSize = 20.sp, modifier = Modifier.clickable { onPlay() }.padding(10.dp))
        }
    }
}

@Composable
private fun NowPlayingScreen(song: Song, playing: Boolean, position: Long, duration: Long, onBack: () -> Unit, onPlay: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit, onSeek: (Long) -> Unit) {
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B10)).padding(horizontal = 24.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("‹", fontSize = 38.sp, modifier = Modifier.clickable { onBack() })
            Text("NOW PLAYING", Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
            Text("⋮", fontSize = 28.sp)
        }
        Spacer(Modifier.height(34.dp))
        Artwork(song, 310.dp)
        Spacer(Modifier.height(30.dp))
        Text(song.title, fontSize = 25.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(song.artist, color = Color.Gray, fontSize = 16.sp)
        Spacer(Modifier.height(24.dp))
        Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f, onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(position), color = Color.Gray, fontSize = 11.sp); Text(formatTime(duration), color = Color.Gray, fontSize = 11.sp) }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Text("↶", fontSize = 28.sp)
            Text("|◀", fontSize = 30.sp, modifier = Modifier.clickable { onPrevious() })
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(36.dp)).background(Color(0xFFB8A7FF)).clickable { onPlay() }, Alignment.Center) { Text(if (playing) "Ⅱ" else "▶", color = Color(0xFF17131F), fontSize = 28.sp) }
            Text("▶|", fontSize = 30.sp, modifier = Modifier.clickable { onNext() })
            Text("↷", fontSize = 28.sp)
        }
        Spacer(Modifier.height(28.dp))
        Text("AURALIVO • ${song.album}", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable private fun EmptyState() { Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No music found on this device", color = Color.Gray) } }

private fun playSong(controller: MediaController?, queue: List<Song>, song: Song) {
    if (controller == null || queue.isEmpty()) return
    val items = queue.map { MediaItem.Builder().setUri(it.uri).setMediaId(it.id.toString()).build() }
    val index = queue.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
    controller.setMediaItems(items, index, 0L)
    controller.prepare()
    controller.play()
}

private fun formatTime(ms: Long): String {
    val total = ms.coerceAtLeast(0) / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

private const val PREFS = "auralivo_prefs"
private const val FAVS = "favorites"
private fun loadFavorites(context: Context): Set<Long> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(FAVS, emptySet())!!.mapNotNull { it.toLongOrNull() }.toSet()
private fun toggleFavorite(context: Context, current: Set<Long>, id: Long): Set<Long> {
    val next = current.toMutableSet().apply { if (!add(id)) remove(id) }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(FAVS, next.map(Long::toString).toSet()).apply()
    return next
}
